import urllib
import re
import csv
import sys
p = str(sys.argv[1])
q = str(sys.argv[2])
#print 'hello'
a = open(""+p+"")
aa = a.read()
aaa = aa.split('\n')

k = 0
while k<len(aaa):

    name_input = aaa[k][0].upper() + aaa[k][1:].lower()
    L = len(name_input)+1

    try:
        ##fob = open(''+ q +'/result.txt','a')
        url = "https://en.wikipedia.org/wiki/" +name_input+""
        htmlfile = urllib.urlopen(url)
        htmltext = htmlfile.read()
    except:
        print "Inetrnet Error"
        
    try:
        if re.findall('<title>',htmltext):
            tit = htmltext.find('<title>')
            tit2 = htmltext.find(' - Wikipedia</title>',tit)
            title = htmltext[tit+7: tit2]
        if title == name_input:
            if re.findall('https://medlineplus.gov/druginfo/meds/',htmltext):
                med = htmltext.find('https://medlineplus.gov/druginfo/meds/')
                med2 = htmltext.find('">',med)
                med3 = htmltext.find('<',med2)
                med_line = htmltext[med2+2: med3]
                
            else:
                med_line = 'Not_found'
                #print name_input+'@Not_found'
            if re.findall('href="/wiki/Pregnancy_category#Australia"',htmltext):
                prg = htmltext.find('href="/wiki/Pregnancy_category#Australia"')
                prg1 = htmltext.find('">',prg)
                prg2 = htmltext.find('<',prg1)
                Pregnancy_category = htmltext[prg1+2: prg2]
                #print 'Pregnancy_category AU : '+Pregnancy_category
                #fob.write(Pregnancy_category+'$')
            else:
                #print 'Pregnancy_category AU : Not found'
                #fob.write('Not_found $')
                Pregnancy_category = 'Not_found'
            if re.findall('href="/wiki/Pregnancy_category#United_States"',htmltext):
                pr = htmltext.find('href="/wiki/Pregnancy_category#United_States"')
                pr1 = htmltext.find('">',pr)
                pr2 = htmltext.find('<',pr1)
                Pregnancy_category1 = htmltext[pr1+2: pr2]
                #fob.write(Pregnancy_category1+'$')
                #print 'Pregnancy_category AU : '+Pregnancy_category1
            else:
                #fob.write('Not_found $')
                #print 'Pregnancy_category US : Not found'
                Pregnancy_category1 = 'Not_found'
            if re.findall('http://www.commonchemistry.org/ChemicalDetail.aspx',htmltext):
                name = htmltext.find('http://www.commonchemistry.org/ChemicalDetail.aspx')
                name1 = htmltext.find('">',name)
                name2 = htmltext.find('<',name1)
                cas = htmltext[name1+2: name2]
                #print 'Cas Number : '+cas
                #fob.write(cas+'$')
            else:
                #print 'Cas Number : Not found'
                #fob.write('Not_found $')
                cas = 'Not_found'
            if re.findall('https://www.drugbank.ca/drugs/',htmltext):
                d_id = htmltext.find('https://www.drugbank.ca/drugs/')
                d_id1 = htmltext.find('">',d_id)
                d_id2 = htmltext.find('<',d_id1)
                drug_id = htmltext[d_id1+2:d_id2]
                #print 'Drug bank id : '+drug_id
                #fob.write(drug_id+'$')
            else:
                #print 'Drug bank id : Not found'
                #fob.write('Not_found $')
                drug_id = 'Not_found'
            if re.findall('http://www.guidetopharmacology.org/GRAC',htmltext):
                IU = htmltext.find('http://www.guidetopharmacology.org/GRAC')
                IU1 = htmltext.find('">',IU)
                IU2 = htmltext.find('<',IU1)
                IUPHAR = htmltext[IU1+2:IU2]
                #print 'IUPHAR : '+IUPHAR
                #fob.write(IUPHAR+'$')
            else:
                #print 'IUPHAR : Not found'
                #fob.write('Not_found $')
                IUPHAR = 'Not_found'
            if re.findall('href="//pubchem.ncbi.nlm.nih.gov/summary/summary',htmltext):
                pb = htmltext.find('href="//pubchem.ncbi.nlm.nih.gov/summary/summary')
                pb1 = htmltext.find('">',pb)
                pb2 = htmltext.find('<',pb1)
                Pubchem_id = htmltext[pb1+2:pb2]
                #print 'PubChem ID : '+ Pubchem_id
                #fob.write(Pubchem_id+'$')
            else:
                #print 'PubChem ID : Not found'
                #fob.write('Not_found $')
                Pubchem_id = 'Not_found'
            if re.findall('http://www.chemspider.com/Chemical-Structure.',htmltext):
                spi = htmltext.find('http://www.chemspider.com/Chemical-Structure.')
                spi1 = htmltext.find('">',spi)
                spi2 = htmltext.find('<',spi1)
                Spi_id = htmltext[spi1+2:spi2]
                #print 'ChemSpider : '+Spi_id
                #fob.write(Spi_id+'$')
            else:
                #print 'ChemSpider : Not found'
                #fob.write('Not_found $')
                Spi_id = 'Not_found'
            if re.findall('http://www.kegg.jp/entry/',htmltext):        
                K = htmltext.find('http://www.kegg.jp/entry/')
                K1 = htmltext.find('">',K)
                K2 = htmltext.find('<',K1)
                KEGG = htmltext[K1+2:K2]
                #print 'KEGG : '+KEGG
                #fob.write(KEGG+'$')
            else:
                #print 'KEGG : Not found'
                #fob.write('Not_found $')
                KEGG = 'Not_found'
            if re.findall('chebiId=CHEBI:',htmltext):
                Ch = htmltext.find('chebiId=CHEBI:')
                Ch1 = htmltext.find('">',Ch)
                Ch2 = htmltext.find('<',Ch1)
                ChEBI = htmltext[Ch1+2:Ch2]
                #print 'ChEBI : '+ChEBI
                #fob.write(ChEBI+'$')
            else:
                #print 'ChEBI : Not found'
                #fob.write('Not_found $')
                ChEBI = 'Not_found'
            if re.findall('https://www.ebi.ac.uk/chembldb/index.php/compound/inspect/',htmltext):
                ChE = htmltext.find('https://www.ebi.ac.uk/chembldb/index.php/compound/inspect/')
                ChE1 = htmltext.find('">',ChE)
                ChE2 = htmltext.find('<',ChE1)
                ChEMBL = htmltext[ChE1+2:ChE2]
                #print 'ChEMBL : '+ChEMBL
                #fob.write(ChEMBL+'$')
            else:
                #print 'ChEMBL : Not found'
                #fob.write('Not_found $')
                ChEMBL = 'Not_found'
            if re.findall('>Molar mass<',htmltext):
                M = htmltext.find('>Molar mass<')
                M1 = htmltext.find('<td>',M)
                M2 = htmltext.find('.',M1)
                mm = htmltext[M1+4:M2+3]
                mm2 = len(mm)
                if mm2 <= 8:
                    #print 'molar mass :'+ mm
                    #fob.write(mm+'$')
                    mm3 = mm
                else:
                    #print 'Molar mass : Not found'
                    #fob.write('Not_found $')
                    mm3 = 'Not_found'
            else:
                #print 'Molar mass : Not found'
                #fob.write('Not_found $')
                mm3 = 'Not_found'
            
            if re.findall('>Density<',htmltext):
                D = htmltext.find('>Density<')
                D5 = htmltext.find('</th>',D)
                D1 = htmltext.find('<td>',D5)
                
                D2 = htmltext.find('&#',D1)
                Density = htmltext[D1+4:D2]
                dl = len(Density)
                if dl <= 5:
                    #Density = htmltext[D1+4:D2]
                    #print 'Density : '+Density 
                    #fob.write(Density+'$')
                    Density1 = Density 
                else:
                    #print 'Density : Not found'
                    #fob.write('Not_found $')
                    Density1 = 'Not_found'
            else:
                #print 'Density : Not found'
                #fob.write('Not_found $')
                Density1 = 'Not_found'
            if re.findall('>Melting point<',htmltext):
                Mel = htmltext.find('>Melting point<')
                Mel1 = htmltext.find('<td>',Mel)
                Mel2 = htmltext.find('&#',Mel1)
                MP = htmltext[Mel1+4:Mel2]
                ml = len(MP)
                if ml <= 5:
                    #print 'Melting point : '+MP +' C'
                    #fob.write(MP+'$')
                    MP1 = MP
                else:
                    #print 'Melting Point : Not found'
                    #fob.write('Not_found $')
                    MP1 = 'Not_found'
            else:
                #print 'Melting Point : Not found'
                #fob.write('Not_found $')
                MP1 = 'Not_found'
            if re.findall('>Boiling point<',htmltext):
                B = htmltext.find('>Boiling point<')
                B1 = htmltext.find('<td>',B)
                B2 = htmltext.find('&#',B1)
                BP = htmltext[B1+4:B2]
                L = len(BP)
                if L <= 5:
                    #fob.write(BP+'$')
                    #print 'Boiling Point :'+BP
                    BP1 = BP
                else:
                    #print 'Boiling Point : Not found'
                    #fob.write('Not_found $')
                    BP1 = 'Not_found'
            else:
                #print 'Boiling Point : Not found'
                #fob.write('Not_found $')
                BP1 = 'Not_found'               
            if re.findall('SMILES',htmltext):
                smi = htmltext.find('SMILES')
                smi1 = htmltext.find('font-size:11px; line-height:120%;',smi)
                smi2 = htmltext.find('">',smi1)
                smi3 = htmltext.find('<',smi2)
                smile = htmltext[smi2+2:smi3]
                #print 'Smile Notation : '+smile
                #fob.write(smile+'$')
            else:
                #print 'Smile Notaion : Not found'
                #fob.write('Not_found $')
                smile = 'Not_found'
            if re.findall('InChI=',htmltext):        
                In = htmltext.find('InChI=')
                In2 = htmltext.find('<',In)
                InChI = htmltext[In+6:In2]
                #print 'InChI : '+InChI
                #fob.write(InChI+'$')
            else:
                #print 'InChiI : Not found'
                #fob.write('Not_found $')
                InChI = 'Not_found'
            if re.findall('Key:',htmltext):
                ke = htmltext.find('Key:')
                ke2 = htmltext.find('<',ke)
                
                Key1 = htmltext[ke+4:ke+10]
                if Key1 == '&#160;':
                    Key = htmltext[ke+10:ke2]
                    #print 'Key : '+Key
                    #fob.write(Key+'\n')
                    Key3 = Key
                else:
                    Key = htmltext[ke+4:ke2]
                    #print 'Key : '+Key
                    #fob.write(Key+'\n')
                    Key3 = Key
            else:
                #print 'Key : Not found'
                #fob.write('Not_found'+'\n')
                Key3 = 'Not_found'

        else:
            print name_input+'@Not_found'

        print name_input+'@'+med_line+'@'+Pregnancy_category+'@'+Pregnancy_category1+'@'+cas+'@'+drug_id+'@'+IUPHAR+'@'+Pubchem_id+'@'+Spi_id+'@'+KEGG+'@'+ChEBI+'@'+ChEMBL+'@'+mm3+'@'+Density1+'@'+MP1+'@'+BP1+'@'+smile+'@'+InChI+'@'+Key3
    except:
        print name_input+"@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found@Not found"
        ##fob.write(name_input +','+'Not found'+'\n')

    k+=1
a.close()
#print "Job Completed"
